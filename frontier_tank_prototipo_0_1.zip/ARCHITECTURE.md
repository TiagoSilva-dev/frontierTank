# Arquitetura

O projeto Godot fica na raiz para reutilizar `assets/` sem duplicar a arte. Cena de entrada em `client/scenes/`. Renderizador Compatibility, resolução lógica 1280×720, filtro nearest, simulação física a 60 Hz.

- `terrain.gd`: máscara RGBA 640×360; cada pixel representa 2 unidades de mundo. A mesma máscara decide apoio, colisão e visual. Crateras removem pixels da máscara e atualizam a textura, sem malha física desatualizada.
- `ballistics.gd`: funções puras para velocidade inicial e aceleração; passo fixo e subpassos espaciais no projétil evitam atravessar terreno.
- `fighter.gd`: vida, queda, movimento com degraus, sprite e arma separados. Apoio acompanha a máscara.
- `projectile.gd`: voo e detecção de colisão de segmento contra máscara e lutadores.
- `match.gd`: máquina de estados, validação das ações, timer, vento, recursos e vitória.
- `hud.gd`: preparação, HUD, pausa e resultado. Só envia intenções ao controlador local.
- `main.gd`: montagem e apresentação do cenário.
- `shared/balance/combat.json`: valores de combate e armas; sem segredos.

Não há servidor online nesta etapa. A autoridade atual é local. Um futuro adaptador de rede deverá substituir a entrada no controlador e reproduzir eventos do servidor; não aceitar dano ou recompensas calculados pelo cliente. Passo fixo não é garantia de determinismo entre linguagens/arquiteturas: a implementação Go precisará de testes de paridade e snapshots.

`profile.gd` mantém um único personagem em `user://profile.json`: arma equipada, experiência, partidas, vitórias e moedas locais. Não há lista de personagens. `character_screen.gd` apresenta os atributos e a mochila; `character_skin.gd` cria molduras de pixels com nove regiões para redimensionamento. Dados locais não serão aceitos como fonte de economia online.

Limitações: máscara sem desabamento de blocos isolados, personagens compostos sem equipamento em camadas de roupa, animações procedurais básicas, efeitos sonoros sintetizados. Sem autenticação, persistência no servidor ou pagamentos.
