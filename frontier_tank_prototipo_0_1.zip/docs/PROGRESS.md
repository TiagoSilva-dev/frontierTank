# Progresso

## Protótipo 0.1
Fundação Godot e combate local funcional: cenário, sprites PixelLab, cinco armas, física, vento, destruição, queda, habilidades básicas, turnos, vitória, pausa e revanche. Tela de personagem única com mochila e atributos reais do protótipo. Persistência local mínima identificada.

## Regra de identidade
Uma conta corresponde a um personagem. Sem lista de personagens por conta nem troca de personagem. Equipamentos e aparência personalizam o mesmo personagem. Convidado local não pertence à conta. No futuro banco, `characters.account_id` terá restrição UNIQUE; criação de conta e personagem será transacional.

## Próxima entrega
Backend Go e protocolo versionado; autenticação, personagem único por conta e salas 1v1. PostgreSQL substituirá o perfil local como autoridade de progresso. Não confiar no arquivo local para importar moedas ou equipamentos online. Validar recompensas e fortalecimento no servidor.

## Arte
Tela de personagem segue a organização da referência sem coluna de múltiplos personagens. Polimento para fidelidade visual exata permanece pendente. Não há menus fingindo sistemas online implementados.
