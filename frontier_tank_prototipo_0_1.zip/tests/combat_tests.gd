extends SceneTree

var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	call_deferred("run_tests")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(message)
	else:
		print("PASS: " + message)

func run_tests() -> void:
	var game: LocalMatch = LocalMatch.new()
	root.add_child(game)
	game.set_physics_process(false)
	game.rng.seed = 12345
	game.start([0, 4])
	check(game.fighters.size() == 2, "two distinct duel participants")
	check(game.active_id == 0 and game.can_act(), "initial legal aiming state")
	var velocity: Vector2 = Ballistics.launch_velocity(45, 50, 1, game.balance)
	var reflected: Vector2 = Ballistics.launch_velocity(45, 50, -1, game.balance)
	check(is_equal_approx(velocity.x, -reflected.x) and is_equal_approx(velocity.y, reflected.y), "aim mirrors horizontally")
	check(Ballistics.launch_velocity(45, 100, 1, game.balance).length() > velocity.length(), "power changes launch speed")
	check(Ballistics.splash_damage(1000, 60, 50, false, 0.5) == 0, "no damage outside blast radius")
	check(Ballistics.splash_damage(0, 60, 50, true, 0.5) == 25, "shield halves damage")
	var ground: Vector2 = game.fighters[0].position + Vector2(0, 10)
	check(game.terrain.solid(ground), "spawn has solid terrain")
	var removed: int = game.terrain.crater(ground, 42)
	check(removed > 0 and not game.terrain.solid(ground), "crater changes the collision mask")
	var initial_y: float = game.fighters[0].position.y
	for i in range(60):
		game.fighters[0].step_fall(1.0 / 60, game.terrain, float(game.balance.gravity))
	check(game.fighters[0].position.y > initial_y + 15, "unsupported fighter falls into crater")
	check(game.fighters[0].settled, "fighter lands on new crater floor")
	check(not game.use_skill("heal"), "full-health heal is rejected without consumption")
	game.fighters[0].hp = 70
	check(game.use_skill("heal") and game.fighters[0].hp == 110, "heal restores configured HP")
	check(not game.use_skill("heal"), "heal cannot be reused")
	check(game.use_skill("shield") and not game.use_skill("shield"), "shield limited to one use")
	game.paused = true
	var before: float = game.remaining
	game._physics_process(1.0)
	game.charge()
	check(game.remaining == before and game.state != LocalMatch.State.PLAYER_CHARGING, "pause freezes timer and blocks charge")
	game.paused = false
	game.charge()
	game.power = 73
	game.release_shot()
	check(game.state == LocalMatch.State.PROJECTILE_FLYING and is_instance_valid(game.projectile), "release creates live projectile")
	var original: TankProjectile = game.projectile
	game.release_shot()
	check(game.projectile == original and not game.use_skill("heal"), "duplicate fire and in-flight skills rejected")
	for i in range(900):
		game._physics_process(1.0 / 60)
		if game.active_id == 1:
			break
	check(game.active_id == 1 and game.state == LocalMatch.State.PLAYER_AIMING, "shot resolves and hands turn to rival")
	game.remaining = 0.01
	for i in range(90):
		game._physics_process(1.0 / 60)
	check(game.active_id == 0, "timer expiry passes turn")
	# Sweep test: a fast shot crossing many mask pixels must hit terrain.
	var bullet: TankProjectile = TankProjectile.new()
	bullet.terrain = game.terrain
	bullet.position = Vector2(400, 300)
	bullet.velocity = Vector2(0, 25000)
	bullet.gravity = 0
	root.add_child(bullet)
	bullet.advance(1.0 / 60)
	check(not bullet.live and bullet.position.y < 600, "fast projectile does not tunnel through ground")
	bullet.queue_free()
	game.fighters[1].hp = 150
	var victim: TankFighter = game.fighters[1]
	game.resolve_impact(victim.center())
	check(victim.hp < 150, "direct blast damages target")
	game.fighters[1].position = Vector2(640, 739)
	game.fighters[1].velocity_y = 300
	game.fighters[1].step_fall(1.0 / 60, game.terrain, float(game.balance.gravity))
	check(game.fighters[1].hp == 0, "falling out of arena eliminates fighter")
	check(game.evaluate_winner() and game.state == LocalMatch.State.MATCH_FINISHED, "elimination ends match")
	check(not game.can_act(), "finished match rejects actions")
	game.start([1, 2])
	check(game.fighters[0].hp == 150 and game.fighters[1].hp == 150 and game.round_number == 1, "rematch resets health and turns")
	check(game.terrain.solid(ground), "rematch restores terrain")
	game.fighters[0].hp = 0
	game.fighters[1].hp = 0
	var result: Array[int] = []
	game.finished.connect(func(winner: int) -> void: result.append(winner))
	game.evaluate_winner()
	check(result == [-1], "simultaneous elimination is a draw")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
