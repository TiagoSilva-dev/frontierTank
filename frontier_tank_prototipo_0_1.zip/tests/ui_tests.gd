extends SceneTree

var errors: int = 0

func _initialize() -> void:
	call_deferred("run_tests")

func check(value: bool, message: String) -> void:
	if value:
		print("PASS: " + message)
	else:
		errors += 1
		push_error(message)

func run_tests() -> void:
	var scene: Node = load("res://client/scenes/main.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	var hud: GameHUD = scene.hud
	check(hud.home.visible and not hud.combat.visible, "home is initial screen")
	hud.show_profile()
	await process_frame
	var screen: CharacterScreen = hud.profile_screen
	check(is_instance_valid(screen) and not hud.home.visible, "single character screen opens")
	screen.select_tab("Atributos")
	screen.select_tab("Histórico")
	screen.select_tab("Perfil")
	screen.filter_items("Armas")
	screen.select_item(2)
	check(screen.selected_label.text.contains("Glacial"), "inventory selection shows real weapon stats")
	screen.filter_items("Mascotes")
	screen.select_item(5)
	check(screen.equip_button.disabled, "visual companion does not fake equip action")
	hud.close_profile()
	await process_frame
	hud.start_match()
	check(hud.combat.visible and hud.game.running and hud.game.visible, "battle starts from home")
	hud.game.charge()
	hud.pause_game()
	check(hud.game.paused and hud.game.state != LocalMatch.State.PLAYER_CHARGING, "pause cancels pending charge")
	hud.pause_game()
	check(not hud.game.paused, "continue restores match")
	hud.return_home()
	await process_frame
	hud.start_match()
	check(hud.game.visible and hud.game.running, "new battle visible after returning home")
	hud.game.running = false
	scene.queue_free()
	await process_frame
	print("UI RESULT: %d failures" % errors)
	quit(1 if errors else 0)
