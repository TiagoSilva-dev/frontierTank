# Frontier Tank: Nova Era

## Entrega 0.1 — duelo na Ilha Celeste
Dois jogadores compartilham teclado ou mouse, alternando turnos de 20 segundos. Cada um começa com 150 PV, uma cura e um escudo. Vence quem eliminar o rival por dano ou queda. Empate se ambos caírem no mesmo impacto.

Mover custa a reserva do turno. Ângulo de 10 a 85 graus, orientação independente e potência carregada ao segurar espaço ou DISPARAR. Vento muda entre turnos. A previsão mostra somente o começo da trajetória; acertar à distância exige estimar potência e vento.

As cinco armas estão disponíveis desde a preparação. Alteram dano e raio da cratera; propriedades especiais de gelo/fogo ainda não fazem parte do protótipo. Mascotes são acompanhantes visuais. Não há economia ou conta simulada.

## Controles
A/D ou setas horizontais: andar. W/S ou setas verticais: ângulo. Q: inverter mira. Espaço: segurar e soltar para disparar. Esc: pausar. Controles equivalentes na interface. Cura e escudo podem ser usados uma vez por jogador, antes de carregar o tiro.

## Etapas seguintes
1. Validar diversão e balanceamento deste duelo local.
2. Servidor Go autoritativo, contrato versionado, autenticação e salas 1v1.
3. Persistência PostgreSQL, inventário, progressão e ferreiro transacional.
4. Campanha, mascotes com habilidades, grupos e ranqueamento.

Entrega atual não representa o jogo comercial completo descrito no documento de referência.
