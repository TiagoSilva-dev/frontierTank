class_name TankProjectile
extends Node2D

signal impacted(point: Vector2)
signal missed
var velocity: Vector2
var wind: float = 0.0
var gravity: float = 420.0
var terrain: DestructibleTerrain
var fighters: Array[TankFighter] = []
var owner_id: int = 0
var age: float = 0.0
var live: bool = true
var trail: PackedVector2Array = []
var texture: Texture2D = preload("res://assets/effects/projetil.png")

func advance(delta: float) -> void:
	if not live:
		return
	age += delta
	velocity += Ballistics.acceleration(wind, gravity) * delta
	var travel: Vector2 = velocity * delta
	var steps: int = maxi(1, ceili(travel.length() / 2.0))
	for i in range(steps):
		position += travel / steps
		var hit: bool = terrain.solid(position)
		for fighter in fighters:
			if fighter.hp > 0 and (fighter.player_id != owner_id or age > 0.25):
				hit = hit or position.distance_to(fighter.center()) < 23.0
		if hit:
			live = false
			impacted.emit(position)
			return
	trail.append(position)
	if trail.size() > 18:
		trail.remove_at(0)
	if position.x < -120 or position.x > 1400 or position.y > 760 or age > 12.0:
		live = false
		missed.emit()
	queue_redraw()

func _draw() -> void:
	for i in range(1, trail.size()):
		draw_line(trail[i - 1] - position, trail[i] - position, Color(1, 0.86, 0.55, float(i) / trail.size() * 0.7), 3)
	draw_texture_rect(texture, Rect2(-12, -12, 24, 24), false)
