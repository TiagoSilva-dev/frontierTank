class_name LocalMatch
extends Node2D

signal changed
signal finished(winner: int)
signal blast(point: Vector2, radius: float)
signal damage_text(point: Vector2, text: String, color: Color)
signal shot_fired

enum State { WAITING_FOR_TURN, TURN_STARTED, PLAYER_MOVING, PLAYER_AIMING, PLAYER_CHARGING, PROJECTILE_FLYING, RESOLVING_DAMAGE, TURN_FINISHED, MATCH_FINISHED }
var state: State = State.WAITING_FOR_TURN
var balance: Dictionary
var terrain: DestructibleTerrain
var fighters: Array[TankFighter] = []
var projectile: TankProjectile
var active_id: int = 0
var round_number: int = 1
var remaining: float = 20.0
var movement: float = 115.0
var power: float = 0.0
var wind: float = 0.0
var resolve_time: float = 0.0
var running: bool = false
var paused: bool = false
var move_input: float = 0.0
var aim_input: float = 0.0
var status_message: String = ""
var rng: RandomNumberGenerator = RandomNumberGenerator.new()

func _init() -> void:
	balance = JSON.parse_string(FileAccess.get_file_as_string("res://shared/balance/combat.json"))
	rng.randomize()

func start(choices: Array[int]) -> void:
	for fighter in fighters:
		fighter.queue_free()
	fighters.clear()
	if is_instance_valid(projectile):
		projectile.queue_free()
	projectile = null
	if is_instance_valid(terrain):
		terrain.queue_free()
	terrain = DestructibleTerrain.new()
	add_child(terrain)
	terrain.rebuild()
	for i in range(2):
		var fighter: TankFighter = TankFighter.new()
		fighter.setup(i, balance.weapons[choices[i]], int(balance.max_hp))
		fighter.position = Vector2(225 if i == 0 else 1055, 0)
		fighter.position.y = terrain.surface_y(fighter.position.x) - 1
		add_child(fighter)
		fighters.append(fighter)
	active_id = 0
	round_number = 1
	running = true
	paused = false
	begin_turn()

func can_act() -> bool:
	return running and not paused and state in [State.TURN_STARTED, State.PLAYER_MOVING, State.PLAYER_AIMING]

func begin_turn() -> void:
	state = State.TURN_STARTED
	remaining = float(balance.turn_seconds)
	movement = float(balance.move_budget)
	power = 0
	move_input = 0
	aim_input = 0
	wind = rng.randf_range(-float(balance.wind_max), float(balance.wind_max))
	for fighter in fighters:
		fighter.active = fighter.player_id == active_id
		fighter.update_pose()
	status_message = "Vez de %s • prepare seu disparo" % fighters[active_id].display_name
	state = State.PLAYER_AIMING
	changed.emit()

func charge() -> void:
	if not can_act() or not fighters[active_id].settled:
		return
	state = State.PLAYER_CHARGING
	power = 0
	move_input = 0
	status_message = "Solte para disparar"

func release_shot() -> void:
	if not running or paused or state != State.PLAYER_CHARGING:
		return
	var shooter: TankFighter = fighters[active_id]
	projectile = TankProjectile.new()
	projectile.position = shooter.muzzle()
	projectile.velocity = Ballistics.launch_velocity(shooter.angle, power, shooter.facing, balance)
	projectile.wind = wind
	projectile.gravity = float(balance.gravity)
	projectile.terrain = terrain
	projectile.fighters = fighters
	projectile.owner_id = active_id
	projectile.impacted.connect(resolve_impact)
	projectile.missed.connect(resolve_miss)
	add_child(projectile)
	state = State.PROJECTILE_FLYING
	status_message = "Projétil em voo"
	shot_fired.emit()
	changed.emit()

func flip_aim() -> void:
	if can_act():
		fighters[active_id].facing *= -1
		fighters[active_id].update_pose()

func use_skill(skill: String) -> bool:
	if not can_act():
		return false
	var fighter: TankFighter = fighters[active_id]
	if skill == "heal" and not fighter.heal_used and fighter.hp < fighter.max_hp:
		var recovered: int = mini(int(balance.heal), fighter.max_hp - fighter.hp)
		fighter.hp += recovered
		fighter.heal_used = true
		damage_text.emit(fighter.center(), "+%d" % recovered, Color("a0e89b"))
	elif skill == "shield" and not fighter.shield_used:
		fighter.shield = true
		fighter.shield_used = true
		fighter.queue_redraw()
	else:
		return false
	changed.emit()
	return true

func resolve_impact(point: Vector2) -> void:
	var weapon: Dictionary = fighters[active_id].weapon
	var radius: float = float(weapon.radius)
	terrain.crater(point, radius)
	blast.emit(point, radius)
	for fighter in fighters:
		var distance: float = maxf(0, point.distance_to(fighter.center()) - 23.0)
		var damage: int = Ballistics.splash_damage(distance, radius * 1.65, int(weapon.damage), fighter.shield, float(balance.shield_multiplier))
		if damage > 0:
			fighter.take_damage(damage)
			fighter.shield = false
			damage_text.emit(fighter.center(), "−%d" % damage, Color("fff0c2"))
	finish_flight("Impacto! O terreno foi alterado")

func resolve_miss() -> void:
	finish_flight("Disparo fora da arena")

func finish_flight(message: String) -> void:
	if is_instance_valid(projectile):
		projectile.queue_free()
	projectile = null
	state = State.RESOLVING_DAMAGE
	resolve_time = 0
	status_message = message
	changed.emit()

func evaluate_winner() -> bool:
	if fighters[0].hp > 0 and fighters[1].hp > 0:
		return false
	var winner: int = -1
	if fighters[0].hp > 0:
		winner = 0
	elif fighters[1].hp > 0:
		winner = 1
	state = State.MATCH_FINISHED
	running = false
	finished.emit(winner)
	changed.emit()
	return true

func _physics_process(delta: float) -> void:
	if not running or paused:
		return
	for fighter in fighters:
		fighter.step_fall(delta, terrain, float(balance.gravity))
	if state != State.PROJECTILE_FLYING and evaluate_winner():
		return
	if state == State.PROJECTILE_FLYING:
		if is_instance_valid(projectile):
			projectile.advance(delta)
	elif state == State.RESOLVING_DAMAGE:
		resolve_time += delta
		if resolve_time > 1.1 and fighters.all(func(f: TankFighter) -> bool: return f.settled or f.hp <= 0):
			next_turn()
	elif state == State.PLAYER_CHARGING:
		power = minf(100, power + float(balance.charge_rate) * delta)
		remaining -= delta
		if remaining <= 0:
			release_shot()
	elif can_act():
		remaining -= delta
		var fighter: TankFighter = fighters[active_id]
		var walking: float = clampf(move_input + keyboard_axis(KEY_A, KEY_D) + keyboard_axis(KEY_LEFT, KEY_RIGHT), -1, 1)
		var aiming: float = clampf(aim_input + keyboard_axis(KEY_S, KEY_W) + keyboard_axis(KEY_DOWN, KEY_UP), -1, 1)
		fighter.angle = clampf(fighter.angle + aiming * 40 * delta, 10, 85)
		if walking != 0 and movement > 0:
			var amount: float = minf(movement, float(balance.move_speed) * delta)
			if fighter.move_ground(amount * walking, terrain):
				movement -= amount
			state = State.PLAYER_MOVING
		else:
			state = State.PLAYER_AIMING
		fighter.update_pose()
		if remaining <= 0:
			status_message = "Tempo esgotado"
			state = State.RESOLVING_DAMAGE
			resolve_time = 0
	queue_redraw()

func next_turn() -> void:
	state = State.TURN_FINISHED
	active_id = 1 - active_id
	round_number += 1
	begin_turn()

func keyboard_axis(negative: Key, positive: Key) -> float:
	return float(Input.is_physical_key_pressed(positive)) - float(Input.is_physical_key_pressed(negative))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and not event.echo:
		if event.physical_keycode == KEY_SPACE:
			if event.pressed:
				charge()
			else:
				release_shot()
		elif event.physical_keycode == KEY_Q and event.pressed:
			flip_aim()

func _draw() -> void:
	if not running or not (can_act() or state == State.PLAYER_CHARGING):
		return
	var fighter: TankFighter = fighters[active_id]
	var point: Vector2 = fighter.muzzle()
	var v: Vector2 = Ballistics.launch_velocity(fighter.angle, power if state == State.PLAYER_CHARGING else 50.0, fighter.facing, balance)
	for i in range(15):
		v += Ballistics.acceleration(wind, float(balance.gravity)) * 0.035
		point += v * 0.035
		if terrain.solid(point):
			break
		draw_circle(point, 2.5, Color(1, 0.96, 0.83, 0.75 - i * 0.035))
