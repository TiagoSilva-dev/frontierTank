class_name PlayerProfile
extends RefCounted

const SAVE_PATH: String = "user://profile.json"
var player_name: String = "Explorador"
var weapon_id: int = 0
var experience: int = 0
var victories: int = 0
var matches: int = 0
var coins: int = 0

func load_profile() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not data is Dictionary:
		return
	player_name = str(data.get("name", "Explorador")).substr(0, 20)
	weapon_id = clampi(int(data.get("weapon", 0)), 0, 4)
	experience = maxi(0, int(data.get("experience", 0)))
	victories = maxi(0, int(data.get("victories", 0)))
	matches = maxi(0, int(data.get("matches", 0)))
	coins = maxi(0, int(data.get("coins", 0)))

func save_profile() -> void:
	var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"version":1, "name":player_name, "weapon":weapon_id, "experience":experience, "victories":victories, "matches":matches, "coins":coins}))

func record_match(won: bool) -> void:
	matches += 1
	if won:
		victories += 1
	experience += 100 if won else 35
	coins += 50 if won else 15
	save_profile()

func level() -> int:
	return 1 + experience / 300 as int
