class_name CharacterSkin
extends RefCounted

static var cached: Dictionary = {}

static func frame(kind: String) -> StyleBoxTexture:
	if cached.has(kind):
		return cached[kind]
	var image: Image = Image.create(96, 96, false, Image.FORMAT_RGBA8)
	var random: RandomNumberGenerator = RandomNumberGenerator.new()
	random.seed = 531
	var base: Color = Color("664329")
	if kind == "paper":
		base = Color("e8d8af")
	elif kind == "slot":
		base = Color("2d3144")
	elif kind == "dark":
		base = Color("282a3b")
	for y in range(96):
		for x in range(96):
			var variation: float = random.randf_range(-0.035, 0.035)
			if kind == "wood":
				variation += sin(y * 0.65 + sin(x * 0.06)) * 0.035
			var color: Color = base.lightened(variation) if variation > 0 else base.darkened(-variation)
			var edge: int = mini(mini(x, 95 - x), mini(y, 95 - y))
			if edge == 0:
				color = Color("30251d")
			elif edge == 1:
				color = Color("6a4b2e")
			elif edge == 2:
				color = Color("e9bf79")
			elif edge == 3:
				color = Color("9e743f")
			elif edge == 4:
				color = Color("473329")
			elif edge == 5:
				color = Color("c99a5b")
			elif edge < 8:
				color = base.darkened(0.24)
			image.set_pixel(x, y, color)
	if kind == "wood":
		for corner: Vector2i in [Vector2i(10, 10), Vector2i(85, 10), Vector2i(10, 85), Vector2i(85, 85)]:
			for dy in range(-6, 7):
				for dx in range(-6, 7):
					var distance: int = absi(dx) + absi(dy)
					if distance < 7:
						image.set_pixel(corner.x + dx, corner.y + dy, Color("ecc786") if distance > 3 else Color("795032"))
	var style: StyleBoxTexture = StyleBoxTexture.new()
	style.texture = ImageTexture.create_from_image(image)
	style.texture_margin_left = 16
	style.texture_margin_right = 16
	style.texture_margin_top = 16
	style.texture_margin_bottom = 16
	style.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_TILE
	style.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_TILE
	cached[kind] = style
	return style
