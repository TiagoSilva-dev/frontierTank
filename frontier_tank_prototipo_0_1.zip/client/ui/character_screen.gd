class_name CharacterScreen
extends Control

var hud: GameHUD
var contents: Control
var category: String = "Todos"
var selected: int = 0
var selected_label: Label
var equip_button: Button
var character_gun: TextureRect
var selection_art: TextureRect
var stats_label: Label
var equipment_slot: TextureRect
var tab_name: String = "Perfil"
var ordered: bool = false

func _ready() -> void:
	selected = hud.profile.weapon_id
	build()

func build() -> void:
	if is_instance_valid(contents):
		remove_child(contents)
		contents.queue_free()
	contents = Control.new()
	add_child(contents)
	# Single account identity. There is intentionally no character roster.
	hud.panel(contents, Rect2(24, 15, 1232, 88), Color("202334"), Color("b68743"))
	hud.label(contents, "FRONTIER\nTANK", Rect2(44, 21, 230, 76), 28, Color("ffd681"))
	hud.label(contents, "NOVA ERA", Rect2(206, 66, 105, 23), 13, Color("edbd66"))
	hud.button(contents, "INÍCIO", Rect2(340, 34, 144, 53), hud.close_profile)
	var current: Button = hud.button(contents, "PERSONAGEM", Rect2(493, 28, 191, 65), func() -> void: select_tab("Perfil"))
	current.add_theme_stylebox_override("normal", GameHUD.box(Color("815127"), Color("ffda80")))
	hud.button(contents, "MOCHILA", Rect2(694, 34, 153, 53), func() -> void: filter_items("Todos"))
	hud.button(contents, "BATALHA", Rect2(858, 34, 149, 53), func() -> void:
		hud.weapon_choices[0] = hud.profile.weapon_id
		hud.start_match())
	hud.art(contents, "res://assets/items/moeda.png", Rect2(1035, 25, 42, 42))
	hud.label(contents, str(hud.profile.coins), Rect2(1083, 25, 135, 39), 25)
	hud.label(contents, "SALDO LOCAL", Rect2(1036, 69, 189, 23), 12, Color("b6c3d5"))
	hud.panel(contents, Rect2(24, 116, 1232, 582), Color("644127"), Color("d4a455"))
	hud.panel(contents, Rect2(32, 123, 1216, 52), Color("442e23"), Color("967044"))
	hud.label(contents, "Personagem", Rect2(49, 129, 310, 37), 28, Color("fff0c7"))
	hud.label(contents, "Uma conta · um personagem", Rect2(851, 135, 365, 26), 17, Color("d9bc8e"))
	for i in range(3):
		var name: String = ["Perfil", "Atributos", "Histórico"][i]
		var tab: Button = hud.button(contents, name, Rect2(43 + i * 167, 184, 160, 37), func() -> void: select_tab(name))
		tab.add_theme_stylebox_override("normal", GameHUD.box(Color("b37a33") if tab_name == name else Color("503b30"), Color("d2aa68"), 4))
	hud.panel(contents, Rect2(42, 228, 580, 452), Color("e6d6af"), Color("ae8a52"))
	hud.panel(contents, Rect2(53, 237, 558, 55), Color("283048"), Color("786651"))
	hud.label(contents, "♛", Rect2(64, 242, 48, 40), 31, Color("ffcd5a"))
	hud.label(contents, hud.profile.player_name, Rect2(119, 239, 285, 33), 24)
	hud.label(contents, "Aventureiro da Ilha Celeste", Rect2(121, 273, 339, 20), 12, Color("d7b76f"))
	hud.label(contents, "Lv. %02d" % hud.profile.level(), Rect2(493, 248, 101, 33), 24, Color("ffd878"))
	if tab_name == "Perfil":
		build_equipment()
	elif tab_name == "Atributos":
		build_attributes()
	else:
		build_history()
	build_inventory()
	apply_skin()

func apply_skin() -> void:
	for node in contents.get_children():
		if node is Panel:
			var kind: String = "wood"
			if node.size.x > 500 and node.size.y > 400:
				kind = "paper" if node.size.x < 700 else "wood"
			elif node.size.x < 90:
				kind = "slot"
			elif node.size.y < 100 and node.position.y > 220:
				kind = "dark"
			node.add_theme_stylebox_override("panel", CharacterSkin.frame(kind))
		elif node is Button:
			node.add_theme_font_size_override("font_size", 17)

func build_equipment() -> void:
	# Warm concentric halo and pedestal are drawn behind the generated sprite.
	var halo: Control = Control.new()
	halo.draw.connect(func() -> void:
		for r in [100, 114, 124]:
			halo.draw_arc(Vector2(331, 424), r, 0, TAU, 64, Color(1, 0.87, 0.43, 0.75), 2)
		for i in range(12):
			var p: Vector2 = Vector2(331, 424) + Vector2.from_angle(i * TAU / 12) * 115
			halo.draw_circle(p, 4, Color("fff6c7"))
		halo.draw_set_transform(Vector2(331, 531), 0, Vector2(1, 0.11))
		halo.draw_circle(Vector2.ZERO, 83, Color(0.5, 0.31, 0.12, 0.25))
	)
	# Ellipse rendered through a scaled circle in a separate draw helper below.
	contents.add_child(halo)
	hud.art(contents, "res://assets/characters/nilo/south.png", Rect2(205, 302, 255, 250))
	character_gun = hud.art(contents, weapon_path(hud.profile.weapon_id), Rect2(339, 411, 123, 112))
	for col in range(2):
		for row in range(3):
			var x: int = 67 if col == 0 else 536
			hud.panel(contents, Rect2(x, 312 + row * 72, 62, 62), Color("f1e4c3"), Color("a69271"))
			if col == 0 and row == 0:
				hud.art(contents, "res://assets/characters/nilo/south.png", Rect2(x + 2, 314, 58, 58))
			elif col == 1 and row == 0:
				equipment_slot = hud.art(contents, weapon_path(hud.profile.weapon_id), Rect2(x + 2, 314, 58, 58))
			elif col == 1 and row == 1:
				hud.art(contents, "res://assets/ui/icone_escudo.png", Rect2(x + 10, 394, 42, 42))
			else:
				hud.label(contents, "◇", Rect2(x + 17, 322 + row * 72, 37, 38), 30, Color("a99574"))
	hud.art(contents, "res://assets/pets/fenix_dourada.png", Rect2(153, 464, 82, 82))
	hud.label(contents, "EXP", Rect2(66, 556, 62, 24), 17, Color("563b29"))
	var exp_bar: ProgressBar = hud.bar(contents, Rect2(114, 559, 472, 18), Color("d99932"))
	exp_bar.value = hud.profile.experience % 300 / 3.0
	hud.label(contents, "%d / 300  •  Nível %d" % [hud.profile.experience % 300, hud.profile.level()], Rect2(203, 580, 301, 22), 13, Color("634c39"))
	hud.panel(contents, Rect2(54, 608, 556, 61), Color("302d30"), Color("93744b"))
	stats_label = hud.label(contents, "", Rect2(70, 613, 524, 49), 16)
	refresh_equipment()

func build_attributes() -> void:
	var w: Dictionary = hud.game.balance.weapons[hud.profile.weapon_id]
	hud.label(contents, "ATRIBUTOS DE COMBATE", Rect2(74, 312, 510, 36), 22, Color("624128"))
	var rows: Array[String] = ["Vida máxima                         %d" % int(hud.game.balance.max_hp), "Dano base da arma                 %d" % int(w.damage), "Raio da cratera                     %d" % int(w.radius), "Movimento por turno            %d" % int(hud.game.balance.move_budget), "Cura por batalha                   %d PV" % int(hud.game.balance.heal), "Escudo                                −50% no próximo impacto"]
	for i in range(rows.size()):
		hud.panel(contents, Rect2(65, 359 + i * 44, 534, 40), Color("42372e"), Color("9c7c50"))
		hud.label(contents, rows[i], Rect2(79, 362 + i * 44, 510, 32), 17)

func build_history() -> void:
	hud.label(contents, "SUA JORNADA", Rect2(77, 320, 485, 41), 27, Color("67452a"))
	hud.label(contents, "%d partidas locais\n\n%d vitórias\n\n%d EXP acumulada\n\n%d moedas conquistadas" % [hud.profile.matches, hud.profile.victories, hud.profile.experience, hud.profile.coins], Rect2(79, 384, 487, 260), 22, Color("4d382d"))

func build_inventory() -> void:
	hud.panel(contents, Rect2(638, 184, 598, 497), Color("d8c8a5"), Color("e2b46c"))
	for i in range(3):
		var filter: String = ["Todos", "Armas", "Mascotes"][i]
		var tab: Button = hud.button(contents, filter, Rect2(649 + i * 143, 194, 137, 41), func() -> void: filter_items(filter))
		tab.add_theme_stylebox_override("normal", GameHUD.box(Color("b17a32") if category == filter else Color("513a2b"), Color("ddb575"), 4))
	hud.label(contents, "7 / 42", Rect2(1101, 200, 122, 29), 18, Color("513a2b"))
	var items: Array[int] = []
	if category != "Mascotes":
		items.assign([0, 1, 2, 3, 4])
		if ordered:
			items.sort_custom(func(a: int, b: int) -> bool: return str(hud.game.balance.weapons[a].name) < str(hud.game.balance.weapons[b].name))
	if category != "Armas":
		items.append(5)
		items.append(6)
	for i in range(42):
		var x: int = 650 + (i % 7) * 82
		var y: int = 245 + (i / 7 as int) * 55
		hud.panel(contents, Rect2(x, y, 76, 50), Color("30374b"), Color("948a77"))
		if i < items.size():
			var item: int = items[i]
			var slot: Button = hud.button(contents, "", Rect2(x, y, 76, 50), func() -> void: select_item(item))
			slot.add_theme_stylebox_override("normal", GameHUD.box(Color("393449"), Color("edba55") if item == selected else Color("8a8191"), 3))
			hud.art(contents, item_path(item), Rect2(x + 13, y + 2, 50, 46))
			if item == hud.profile.weapon_id:
				hud.label(contents, "E", Rect2(x + 59, y + 29, 16, 19), 13, Color("ffe89f"))
	hud.panel(contents, Rect2(650, 582, 574, 46), Color("44372c"), Color("a38357"))
	selected_label = hud.label(contents, "", Rect2(662, 586, 546, 37), 16)
	equip_button = hud.button(contents, "EQUIPAR", Rect2(650, 637, 213, 34), equip_selected)
	equip_button.add_theme_stylebox_override("normal", GameHUD.box(Color("a56525"), Color("e8b566"), 5))
	hud.button(contents, "ORGANIZAR", Rect2(873, 637, 172, 34), func() -> void:
		ordered = not ordered
		build())
	hud.button(contents, "VOLTAR", Rect2(1055, 637, 169, 34), hud.close_profile)
	refresh_selection()

func weapon_path(index: int) -> String:
	return "res://assets/weapons/%s.png" % hud.game.balance.weapons[index].id

func item_path(index: int) -> String:
	if index < 5:
		return weapon_path(index)
	return "res://assets/pets/%s.png" % ("fenix_dourada" if index == 5 else "raposa_glacial")

func refresh_selection() -> void:
	if selected < 5:
		var w: Dictionary = hud.game.balance.weapons[selected]
		selected_label.text = "%s  •  Dano %d  •  Cratera %d" % [w.name, w.damage, w.radius]
		equip_button.disabled = selected == hud.profile.weapon_id
		equip_button.text = "EQUIPADO" if equip_button.disabled else "EQUIPAR"
	else:
		selected_label.text = "%s • acompanhante visual" % ("Fênix Dourada" if selected == 5 else "Raposa Glacial")
		equip_button.disabled = true
		equip_button.text = "VISUAL DO DUELO"

func refresh_equipment() -> void:
	var w: Dictionary = hud.game.balance.weapons[hud.profile.weapon_id]
	character_gun.texture = load(weapon_path(hud.profile.weapon_id))
	equipment_slot.texture = character_gun.texture
	stats_label.text = "VIDA  %d       DANO  %d       CRATERA  %d\nArma equipada: %s" % [hud.game.balance.max_hp, w.damage, w.radius, w.name]

func select_item(index: int) -> void:
	selected = index
	build()

func equip_selected() -> void:
	if selected >= 5:
		return
	hud.profile.weapon_id = selected
	hud.profile.save_profile()
	hud.weapon_choices[0] = selected
	hud.audio.tone(480, 0.14)
	build()

func filter_items(filter: String) -> void:
	category = filter
	build()

func select_tab(value: String) -> void:
	tab_name = value
	build()
