# Frontier Tank: Nova Era

Protótipo Godot 4.7.2 de artilharia 2D com arte PixelLab. Abra **Jogar.cmd** para jogar neste computador, ou importe **project.godot** no Godot e pressione F5. Em outro computador, instale Godot 4.7 e defina `GODOT_BIN` para seu executável. Não precisa de servidor para o duelo local.

## Funcionalidades
- Dois jogadores alternando no mesmo computador, turnos de 20 segundos.
- Movimento limitado por turno, direção, ângulo, carga de potência e vento variável.
- Colisão por subpassos, explosões, dano radial, cratera e queda.
- Vitória, empate, pausa, retorno ao início e revanche.
- Cinco armas com dano/raio próprios; uma cura e um escudo por jogador.
- Sons sintetizados com opção de silenciar, partículas e previsão parcial de trajetória.
- Tela de personagem inspirada na referência: equipamento, mochila, atributos e histórico.
- **Um único personagem no perfil local.** O segundo participante do duelo é convidado; não é um personagem adicional da conta.
- Arma equipada, experiência, vitórias e moedas salvas em `user://profile.json`. Isso não é autenticação ou economia online. Os itens iniciais estão disponíveis para testar.

## Controles
| Ação | Tecla |
|---|---|
| Andar | A/D ou ←/→ |
| Ajustar mira | W/S ou ↑/↓ |
| Inverter mira | Q |
| Carregar/disparar | Segurar/soltar Espaço |
| Pausar | Esc |

Há botões equivalentes na interface. Cura e escudo ficam ao lado do disparo. Andar muda a direção da mira; Q permite corrigir sem andar. A trajetória pontilhada mostra apenas o começo do voo.

## Validação
`powershell -File tools/run.ps1 -Test`

Testes cobrem máscara do terreno, queda, trajetória, dano, habilidades, pausa, ações duplicadas, tempo, mudança de turno, vitória, empate, revanche e navegação da interface. Capturas renderizadas pelo Godot em `docs/`.

## Limites desta entrega
A tela mantém a composição da referência, mas ainda não é visualmente idêntica: faltam ornamentos e sprites definitivos. O terreno usa arte procedural temporária sobre a máscara destrutível. Não há animações quadro a quadro, multiplayer online, login, ferreiro, compra/venda, guilda ou campanha. As armas de gelo/fogo diferem em dano/raio; efeitos de status virão depois. Níveis locais não aumentam atributos nesta etapa. Moedas locais são recompensa acumulada, sem loja.

Próximas fases: `GAME_DESIGN_DOCUMENT.md`, `ARCHITECTURE.md` e `docs/PROGRESS.md`.
