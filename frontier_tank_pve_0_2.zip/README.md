# Frontier Tank: Nova Era — PvE 0.2

Abra **Jogar.cmd** para iniciar com o Godot instalado neste computador, ou importe **project.godot** no Godot 4.7 e pressione F5. Em outro computador, configure GODOT_BIN com o caminho do executável Godot.

## Jogue a primeira expedição
Na cidade celeste, escolha uma arma e clique no portal **Templo do Sol** ou em **Iniciar Expedição**. Enfrente Rei Hélio controlado por IA. Ele entra em fúria quando perde metade da vida.

- A/D ou setas: movimento.
- W/S ou setas verticais: ângulo.
- Q: inverter mira.
- Segurar/soltar Espaço: carregar e disparar.
- Esc: pausa. Cura e escudo nos botões do combate.

A batalha inclui vento, terreno destrutível, queda, dano, vitória, derrota e nova tentativa. Cada perfil tem **um único personagem**, com mochila e arma equipada. O progresso é salvo localmente em user://profile.json; não é uma conta online.

## Arte integrada
Cinco imagens novas e três animações reais geradas no MCP PixelLab: repouso do herói, repouso do chefe e ataque do chefe. Cenário, cidade, portal, chão e inimigo estão usados no jogo. A terceira imagem enviada orientou a arte; as duas imagens de DDtank serviram apenas como referência de composição e funcionamento.

## Verificação
Execute: `powershell -File tools/run.ps1 -Test`

São 52 verificações de combate, interface e PvE. Capturas e GIFs em docs/. Detalhes de arte, parâmetros e limitações em [docs/PVE.md](docs/PVE.md).

Esta entrega possui uma missão solo, não a campanha completa. Não há multiplayer online, login, ferreiro, loja ou cooperativo. A arte segue a direção da referência, mas ainda não tem fidelidade visual idêntica.
