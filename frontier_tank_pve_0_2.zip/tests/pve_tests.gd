extends SceneTree

var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	call_deferred("run_tests")

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)
	else:
		print("PASS: " + message)

func run_tests() -> void:
	var game: LocalMatch = LocalMatch.new()
	root.add_child(game)
	game.set_physics_process(false)
	game.rng.seed = 123
	# Remove intentional aim dispersion to verify the solver independently.
	game.balance.pve.power_error = 0.0
	game.start([0, 4], true)
	check(game.pve and game.fighters[1].is_boss, "PvE creates original boss instead of second player")
	check(game.terrain.solid(Vector2(640, 520)), "temple has continuous destructible floor")
	check(game.fighters[0].idle_animation.frames.size() == 5, "hero PixelLab idle frames loaded")
	check(game.fighters[1].idle_animation.frames.size() == 5, "boss PixelLab idle frames loaded")
	check(game.fighters[1].attack_animation.frames.size() == 9, "boss PixelLab attack frames loaded")
	game.active_id = 1
	game.begin_turn()
	check(not game.can_act(), "human actions blocked during AI turn")
	game.charge()
	check(game.state == LocalMatch.State.PLAYER_AIMING, "human cannot charge the boss weapon")
	check(not game.use_skill("shield"), "human cannot spend boss skills")
	game.paused = true
	game._physics_process(5)
	check(game.ai_time == 0, "pause freezes AI telegraph")
	game.paused = false
	for i in range(150):
		game._physics_process(1.0 / 60)
	check(game.state == LocalMatch.State.PROJECTILE_FLYING, "AI calculates and fires autonomously")
	check(game.fighters[1].attack_animation.visible, "boss cast animation triggered by actual attack")
	for i in range(700):
		game._physics_process(1.0 / 60)
		if game.active_id == 0 or not game.running:
			break
	check(game.active_id == 0, "AI attack resolves back to player turn")
	check(game.fighters[0].hp < game.fighters[0].max_hp, "AI can hit player using terrain and wind")
	game.fighters[1].hp = 100
	game.active_id = 1
	game.begin_turn()
	check(game.boss_enraged and game.fighters[1].weapon.damage == 42, "boss enrages at half health")
	check(game.status_message.contains("FÚRIA"), "strong attack is announced")
	game.fighters[1].hp = 0
	check(game.evaluate_winner(), "defeating boss ends expedition")
	game.start([0, 4], true)
	check(not game.boss_enraged and game.fighters[1].hp == 240, "retry resets boss phase and health")
	game.queue_free()
	await process_frame
	print("PVE RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
