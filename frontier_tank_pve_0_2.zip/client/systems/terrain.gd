class_name DestructibleTerrain
extends Node2D

const WIDTH: int = 640
const HEIGHT: int = 360
const PIXEL: float = 2.0
var mask: Image
var surface_texture: ImageTexture
var temple: bool = false

func rebuild() -> void:
	mask = Image.create(WIDTH, HEIGHT, false, Image.FORMAT_RGBA8)
	mask.fill(Color.TRANSPARENT)
	var stone_image: Image
	if temple:
		stone_image = load("res://assets/pve/templo_bloco.png").get_image()
	for x in range(WIDTH):
		if not temple and x > 272 and x < 366:
			continue
		var top: int = 223 + roundi(sin(x * 0.018) * 14.0 + sin(x * 0.057) * 4.0)
		var bottom: int = 318 - roundi(absf(sin(x * 0.022)) * 16.0)
		if temple:
			top = 250
			bottom = 345
		for y in range(top, bottom):
			var color: Color
			if y < top + 3:
				color = Color("afd77a")
			elif y < top + 8:
				color = Color("648951") if (x + y) % 7 < 4 else Color("7aa352")
			else:
				var stone: int = ((x / 12) as int + (y / 9) as int * 3) % 4
				color = [Color("70615f"), Color("897367"), Color("5b5260"), Color("a08873")][stone]
				if y % 9 == 0 or (x + (y / 9 as int) * 6) % 15 == 0:
					color = Color("403e50")
				if y > bottom - 8:
					color = color.darkened(0.25)
			if temple:
				color = stone_image.get_pixel(x % stone_image.get_width(), y % stone_image.get_height())
				if y < top + 3:
					color = Color("f6ce78")
			mask.set_pixel(x, y, color)
	if surface_texture == null:
		surface_texture = ImageTexture.create_from_image(mask)
	else:
		surface_texture.update(mask)
	queue_redraw()

func solid(point: Vector2) -> bool:
	var x: int = floori(point.x / PIXEL)
	var y: int = floori(point.y / PIXEL)
	return x >= 0 and x < WIDTH and y >= 0 and y < HEIGHT and mask.get_pixel(x, y).a > 0.5

func surface_y(x: float, start: float = 0.0) -> float:
	for y in range(maxi(0, floori(start / PIXEL)), HEIGHT):
		if solid(Vector2(x, y * PIXEL)):
			return y * PIXEL
	return 760.0

func crater(center: Vector2, radius: float) -> int:
	var removed: int = 0
	var c: Vector2 = center / PIXEL
	var r: float = radius / PIXEL
	for y in range(maxi(0, floori(c.y - r)), mini(HEIGHT, ceili(c.y + r) + 1)):
		for x in range(maxi(0, floori(c.x - r)), mini(WIDTH, ceili(c.x + r) + 1)):
			var dist: float = Vector2(x, y).distance_to(c)
			if dist <= r and mask.get_pixel(x, y).a > 0.0:
				mask.set_pixel(x, y, Color.TRANSPARENT)
				removed += 1
			elif dist < r + 2.0 and mask.get_pixel(x, y).a > 0.0:
				mask.set_pixel(x, y, Color("3c354a"))
	surface_texture.update(mask)
	queue_redraw()
	return removed

func _draw() -> void:
	if surface_texture != null:
		draw_texture_rect(surface_texture, Rect2(0, 0, WIDTH * PIXEL, HEIGHT * PIXEL), false)
