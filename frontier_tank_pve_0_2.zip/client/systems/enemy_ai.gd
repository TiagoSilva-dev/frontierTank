class_name EnemyAI
extends RefCounted

static func choose_shot(shooter: TankFighter, target: TankFighter, terrain: DestructibleTerrain, wind: float, balance: Dictionary) -> Vector2:
	var best: Vector2 = Vector2(50, 60)
	var best_distance: float = INF
	for angle in range(30, 81, 5):
		for power in range(30, 91, 3):
			var point: Vector2 = shooter.position + Vector2(-60, -95)
			var velocity: Vector2 = Ballistics.launch_velocity(angle, power, -1, balance)
			for tick in range(440):
				velocity += Ballistics.acceleration(wind, float(balance.gravity)) / 60.0
				point += velocity / 60.0
				var distance: float = point.distance_to(target.center())
				if distance < best_distance:
					best_distance = distance
					best = Vector2(angle, power)
				if terrain.solid(point) or point.y > 740 or point.x < 0:
					break
	return best
