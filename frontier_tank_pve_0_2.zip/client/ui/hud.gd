class_name GameHUD
extends Control

const INK: Color = Color("142239")
const GOLD: Color = Color("efbc60")
const CREAM: Color = Color("fff0ce")
var game: LocalMatch
var audio: GameAudio
var profile: PlayerProfile = PlayerProfile.new()
var home: Control
var combat: Control
var modal: Control
var profile_screen: CharacterScreen
var health_labels: Array[Label] = []
var health_bars: Array[ProgressBar] = []
var time_label: Label
var wind_label: Label
var angle_label: Label
var power_label: Label
var move_label: Label
var message_label: Label
var power_bar: ProgressBar
var fire_button: Button
var heal_button: Button
var shield_button: Button
var weapon_choices: Array[int] = [0, 4]
var selectors: Array[OptionButton] = []
var portraits: Array[TextureRect] = []
var turn_label: Label

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	profile.load_profile()
	weapon_choices[0] = profile.weapon_id
	var ui_theme: Theme = Theme.new()
	ui_theme.default_font_size = 18
	ui_theme.set_color("font_color", "Label", CREAM)
	ui_theme.set_color("font_color", "Button", CREAM)
	ui_theme.set_color("font_hover_color", "Button", Color.WHITE)
	ui_theme.set_color("font_disabled_color", "Button", Color("8e9aab"))
	ui_theme.set_stylebox("normal", "Button", box(INK, Color("60718c"), 8))
	ui_theme.set_stylebox("hover", "Button", box(Color("294564"), GOLD, 8))
	ui_theme.set_stylebox("pressed", "Button", box(Color("3d546d"), GOLD, 8))
	ui_theme.set_stylebox("disabled", "Button", box(Color("1c293c"), Color("344154"), 8))
	ui_theme.set_stylebox("normal", "OptionButton", box(INK, GOLD, 6))
	theme = ui_theme
	build_home()
	build_combat()
	combat.hide()
	game.finished.connect(show_result)

static func box(color: Color, border: Color, radius: int = 8) -> StyleBoxFlat:
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	return style

func panel(parent: Node, rect: Rect2, color: Color = INK, border: Color = Color("657189")) -> Panel:
	var node: Panel = Panel.new()
	node.position = rect.position
	node.size = rect.size
	node.add_theme_stylebox_override("panel", box(color, border))
	parent.add_child(node)
	return node

func label(parent: Node, text: String, rect: Rect2, font_size: int = 18, color: Color = CREAM) -> Label:
	var node: Label = Label.new()
	node.text = text
	node.position = rect.position
	node.size = rect.size
	node.add_theme_font_size_override("font_size", font_size)
	node.add_theme_color_override("font_color", color)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(node)
	return node

func button(parent: Node, text: String, rect: Rect2, action: Callable = Callable()) -> Button:
	var node: Button = Button.new()
	node.text = text
	node.position = rect.position
	node.size = rect.size
	node.focus_mode = Control.FOCUS_NONE
	if action.is_valid():
		node.pressed.connect(action)
	parent.add_child(node)
	return node

func art(parent: Node, path: String, rect: Rect2) -> TextureRect:
	var node: TextureRect = TextureRect.new()
	node.texture = load(path)
	node.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	node.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	node.position = rect.position
	node.size = rect.size
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(node)
	return node

func bar(parent: Node, rect: Rect2, color: Color) -> ProgressBar:
	var node: ProgressBar = ProgressBar.new()
	node.position = rect.position
	node.size = rect.size
	node.show_percentage = false
	node.add_theme_stylebox_override("background", box(Color("0e172b"), Color("52617a"), 5))
	node.add_theme_stylebox_override("fill", box(color, color.lightened(0.25), 5))
	for part: String in ["background", "fill"]:
		var style: StyleBox = node.get_theme_stylebox(part).duplicate()
		style.content_margin_top = 0
		style.content_margin_bottom = 0
		node.add_theme_stylebox_override(part, style)
	node.size = rect.size
	parent.add_child(node)
	return node

func build_home() -> void:
	home = Control.new()
	add_child(home)
	panel(home, Rect2(24, 20, 1232, 92), Color(0.06, 0.10, 0.18, 0.94), GOLD)
	label(home, "FRONTIER TANK", Rect2(46, 28, 480, 49), 34, GOLD)
	label(home, "NOVA ERA  /  EXPEDIÇÕES PvE", Rect2(48, 79, 530, 22), 15)
	button(home, "PERSONAGEM & MOCHILA", Rect2(727, 41, 310, 48), show_profile)
	button(home, "Som: ligado", Rect2(1050, 41, 184, 48), toggle_sound)
	art(home, "res://assets/pve/portal.png", Rect2(840, 208, 220, 220))
	var gate: Button = button(home, "TEMPLO DO SOL  →", Rect2(820, 406, 276, 50), start_match)
	gate.add_theme_stylebox_override("normal", box(Color("865025"), GOLD))
	panel(home, Rect2(30, 476, 380, 213), Color(0.07, 0.12, 0.22, 0.96), GOLD)
	art(home, "res://assets/characters/nilo/south.png", Rect2(35, 491, 132, 175))
	label(home, profile.player_name, Rect2(171, 499, 224, 36), 23)
	label(home, "SEU ÚNICO PERSONAGEM", Rect2(171, 542, 225, 25), 12, GOLD)
	var select: OptionButton = OptionButton.new()
	select.position = Vector2(171, 586)
	select.size = Vector2(220, 44)
	for weapon: Dictionary in game.balance.weapons:
		select.add_item(weapon.name)
	select.select(weapon_choices[0])
	select.item_selected.connect(func(index: int) -> void: weapon_choices[0] = index)
	home.add_child(select)
	selectors.append(select)
	label(home, "Progresso salvo neste computador", Rect2(170, 652, 226, 22), 12)
	panel(home, Rect2(670, 482, 578, 207), Color(0.07, 0.10, 0.18, 0.96), GOLD)
	art(home, "res://assets/pve/rei_sol.png", Rect2(1079, 486, 156, 175))
	label(home, "01  /  O GUARDIÃO SOLAR", Rect2(694, 500, 382, 34), 24, GOLD)
	label(home, "Derrote Rei Hélio no Templo do Sol.", Rect2(695, 543, 380, 26), 17)
	label(home, "Fúria solar quando a vida cair a 50%.", Rect2(695, 578, 380, 25), 16, GOLD)
	button(home, "INICIAR EXPEDIÇÃO", Rect2(694, 614, 364, 52), start_match)
	label(home, "A/D mover · W/S mirar · Q virar · segure e solte ESPAÇO", Rect2(430, 698, 822, 20), 13)

func start_match() -> void:
	clear_modal()
	if is_instance_valid(profile_screen):
		profile_screen.queue_free()
	home.hide()
	combat.show()
	profile.weapon_id = weapon_choices[0]
	profile.save_profile()
	game.start(weapon_choices, true)
	game.show()
	game.fighters[0].display_name = profile.player_name
	game.status_message = "Vez de %s • prepare seu disparo" % profile.player_name

func build_combat() -> void:
	combat = Control.new()
	combat.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(combat)
	for i in range(2):
		var x: int = 24 if i == 0 else 932
		panel(combat, Rect2(x, 20, 324, 92), Color(0.055, 0.095, 0.18, 0.93), Color("7185a4"))
		portraits.append(art(combat, "res://assets/characters/nilo/south.png" if i == 0 else "res://assets/pve/rei_sol.png", Rect2(x, 20, 82, 88)))
		health_labels.append(label(combat, "", Rect2(x + 83, 30, 235, 28), 20))
		var hp: ProgressBar = bar(combat, Rect2(x + 83, 69, 220, 18), Color("43b9dc") if i == 0 else Color("ee756f"))
		hp.max_value = float(game.balance.max_hp)
		health_bars.append(hp)
	panel(combat, Rect2(452, 16, 376, 99), Color(0.055, 0.095, 0.18, 0.91), GOLD)
	turn_label = label(combat, "TURNO 1", Rect2(473, 26, 130, 24), 15, GOLD)
	time_label = label(combat, "20s", Rect2(692, 23, 114, 34), 26)
	wind_label = label(combat, "VENTO", Rect2(473, 65, 332, 32), 23)
	button(combat, "Ⅱ", Rect2(845, 29, 56, 54), pause_game)
	panel(combat, Rect2(24, 571, 1232, 130), Color(0.055, 0.085, 0.16, 0.98), Color("586c8c"))
	message_label = label(combat, "", Rect2(350, 127, 580, 36), 18)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_color_override("font_shadow_color", Color("182342"))
	message_label.add_theme_constant_override("shadow_offset_y", 2)
	label(combat, "MOVIMENTO", Rect2(43, 584, 186, 22), 13, Color("a6bfd7"))
	hold_button("◀", Rect2(42, 615, 57, 51), "move_input", -1)
	hold_button("▶", Rect2(104, 615, 57, 51), "move_input", 1)
	move_label = label(combat, "", Rect2(41, 671, 154, 22), 12)
	angle_label = label(combat, "45°", Rect2(185, 580, 158, 32), 24, GOLD)
	hold_button("−", Rect2(183, 615, 48, 51), "aim_input", -1)
	hold_button("+", Rect2(235, 615, 48, 51), "aim_input", 1)
	button(combat, "↔", Rect2(289, 615, 49, 51), game.flip_aim)
	label(combat, "POTÊNCIA  •  SEGURE E SOLTE", Rect2(365, 585, 495, 25), 15, Color("a6bfd7"))
	power_bar = bar(combat, Rect2(365, 626, 488, 28), Color("eeb75d"))
	power_label = label(combat, "0", Rect2(857, 622, 52, 38), 25, GOLD)
	label(combat, "0          20          40          60          80         100", Rect2(365, 661, 502, 23), 13, Color("a6bfd7"))
	heal_button = button(combat, "CURA", Rect2(927, 587, 119, 43), func() -> void: game.use_skill("heal"))
	heal_button.tooltip_text = "Recupera até 40 PV. Uma vez por jogador."
	shield_button = button(combat, "ESCUDO", Rect2(927, 643, 119, 43), func() -> void: game.use_skill("shield"))
	shield_button.tooltip_text = "Reduz o próximo dano pela metade. Uma vez por jogador."
	fire_button = button(combat, "DISPARAR", Rect2(1065, 586, 173, 100))
	fire_button.add_theme_stylebox_override("normal", box(Color("ac522d"), GOLD, 16))
	fire_button.add_theme_font_size_override("font_size", 23)
	fire_button.button_down.connect(game.charge)
	fire_button.button_up.connect(game.release_shot)

func hold_button(text: String, rect: Rect2, field: String, value: float) -> void:
	var control: Button = button(combat, text, rect)
	control.button_down.connect(func() -> void: game.set(field, value))
	control.button_up.connect(func() -> void: game.set(field, 0.0))
	control.mouse_exited.connect(func() -> void: game.set(field, 0.0))

func _process(_delta: float) -> void:
	if not combat.visible or game.fighters.size() != 2:
		return
	for i in range(2):
		health_labels[i].text = "%s  %d / %d" % [game.fighters[i].display_name, game.fighters[i].hp, game.fighters[i].max_hp]
		health_bars[i].max_value = game.fighters[i].max_hp
		health_bars[i].value = game.fighters[i].hp
	turn_label.text = "TURNO %02d" % game.round_number
	time_label.text = "IA" if game.pve and game.active_id == 1 else "%02ds" % maxi(0, ceili(game.remaining))
	time_label.modulate = Color("ff9f86") if game.remaining < 6 else Color.WHITE
	wind_label.text = "VENTO  %s  %.1f" % ["→" if game.wind >= 0 else "←", absf(game.wind) / 10]
	angle_label.text = "MIRA  %d°" % roundi(game.fighters[game.active_id].angle)
	move_label.text = "%d%% restante" % roundi(game.movement / float(game.balance.move_budget) * 100)
	power_bar.value = game.power
	power_label.text = str(roundi(game.power))
	message_label.text = game.status_message
	var fighter: TankFighter = game.fighters[game.active_id]
	heal_button.disabled = not game.can_act() or fighter.heal_used or fighter.hp >= fighter.max_hp
	shield_button.disabled = not game.can_act() or fighter.shield_used
	fire_button.disabled = (game.pve and game.active_id == 1) or not (game.can_act() or game.state == LocalMatch.State.PLAYER_CHARGING)
	fire_button.text = "SOLTE!" if game.state == LocalMatch.State.PLAYER_CHARGING else "DISPARAR"

func clear_modal() -> void:
	if is_instance_valid(modal):
		modal.queue_free()
	modal = null

func overlay(title: String, subtitle: String) -> Control:
	clear_modal()
	modal = Control.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(modal)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.09, 0.76)
	dim.size = Vector2(1280, 720)
	modal.add_child(dim)
	panel(modal, Rect2(365, 200, 550, 320), INK, GOLD)
	label(modal, title, Rect2(395, 229, 490, 56), 36, GOLD).horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label(modal, subtitle, Rect2(395, 295, 490, 50), 17).horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return modal

func pause_game() -> void:
	if not game.running:
		return
	if game.paused:
		game.paused = false
		clear_modal()
		return
	# Pausing cancels a charge so a released key cannot leave it stuck.
	if game.state == LocalMatch.State.PLAYER_CHARGING:
		game.state = LocalMatch.State.PLAYER_AIMING
		game.power = 0
	game.paused = true
	game.move_input = 0
	game.aim_input = 0
	overlay("BATALHA PAUSADA", "Respire. A próxima jogada pode mudar tudo.")
	button(modal, "CONTINUAR", Rect2(403, 375, 220, 59), pause_game)
	button(modal, "SAIR DA BATALHA", Rect2(641, 375, 235, 59), return_home)

func show_result(winner: int) -> void:
	profile.record_match(winner == 0)
	var title: String = "EMPATE" if winner < 0 else "%s VENCEU!" % game.fighters[winner].display_name.to_upper()
	var reward: String = "+100 EXP • +50 moedas" if winner == 0 else "+35 EXP • +15 moedas"
	overlay(title, "Recompensa local para seu personagem\n" + reward)
	button(modal, "REVANCHE", Rect2(403, 385, 220, 59), start_match)
	button(modal, "VOLTAR AO INÍCIO", Rect2(641, 385, 235, 59), return_home)

func return_home() -> void:
	game.running = false
	game.paused = false
	game.hide()
	combat.hide()
	clear_modal()
	home.show()

func show_profile() -> void:
	home.hide()
	profile_screen = CharacterScreen.new()
	profile_screen.hud = self
	add_child(profile_screen)

func close_profile() -> void:
	profile_screen.queue_free()
	weapon_choices[0] = profile.weapon_id
	selectors[0].select(profile.weapon_id)
	home.show()

func toggle_sound() -> void:
	audio.enabled = not audio.enabled
	for child in home.get_children():
		if child is Button and child.text.begins_with("Som:"):
			child.text = "Som: ligado" if audio.enabled else "Som: desligado"

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_ESCAPE:
		pause_game()
