class_name PixelAnimation
extends Sprite2D

var frames: Array[Texture2D] = []
var fps: float = 7.0
var elapsed: float = 0.0
var frozen: bool = false

func _ready() -> void:
	add_to_group("pixel_animations")

func load_frames(folder: String, count: int, height: float) -> void:
	for i in range(count):
		var path: String = "%s/frame_%02d.png" % [folder, i]
		if ResourceLoader.exists(path):
			frames.append(load(path))
	if frames.is_empty():
		return
	texture = frames[0]
	scale = Vector2.ONE * height / texture.get_height()
	var bottom: float = texture.get_image().get_used_rect().end.y
	position.y = height * 0.5 - bottom * scale.y

func _process(delta: float) -> void:
	if frozen or frames.is_empty():
		return
	elapsed += delta
	texture = frames[int(elapsed * fps) % frames.size()]
