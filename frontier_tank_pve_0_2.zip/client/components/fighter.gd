class_name TankFighter
extends Node2D

var player_id: int = 0
var display_name: String = "Nilo"
var hp: int = 150
var max_hp: int = 150
var facing: int = 1
var angle: float = 45.0
var velocity_y: float = 0.0
var shield: bool = false
var heal_used: bool = false
var shield_used: bool = false
var active: bool = false
var settled: bool = true
var weapon: Dictionary
var body: Sprite2D
var gun: Sprite2D
var pet: Sprite2D
var east_texture: Texture2D
var west_texture: Texture2D
var pulse: float = 0.0
var is_boss: bool = false
var hit_radius: float = 23.0
var idle_animation: PixelAnimation
var attack_animation: PixelAnimation
var attack_time: float = 0.0

func setup_pve_visual(boss: bool) -> void:
	is_boss = boss
	if boss:
		display_name = "Rei Hélio"
		hit_radius = 55.0
		body.texture = load("res://assets/pve/rei_sol.png")
		body.region_enabled = false
		body.scale = Vector2.ONE * 1.5
		body.position = Vector2(0, -96)
		gun.hide()
		pet.hide()
	idle_animation = PixelAnimation.new()
	idle_animation.load_frames("res://assets/pve/%s" % ("boss_idle" if boss else "hero_idle"), 5, 192 if boss else 110)
	add_child(idle_animation)
	if not idle_animation.frames.is_empty():
		body.hide()
	if boss:
		attack_animation = PixelAnimation.new()
		attack_animation.load_frames("res://assets/pve/boss_attack", 9, 192)
		attack_animation.hide()
		add_child(attack_animation)

func animate_attack() -> void:
	if is_instance_valid(attack_animation) and not attack_animation.frames.is_empty():
		attack_time = 1.2
		attack_animation.elapsed = 0
		attack_animation.show()
		idle_animation.hide()

func setup(id: int, choice: Dictionary, health: int) -> void:
	player_id = id
	display_name = "Nilo" if id == 0 else "Lia"
	facing = 1 if id == 0 else -1
	hp = health
	max_hp = health
	weapon = choice
	var folder: String = "nilo" if id == 0 else "lia"
	east_texture = load("res://assets/characters/%s/east.png" % folder)
	west_texture = load("res://assets/characters/%s/west.png" % folder)
	body = Sprite2D.new()
	body.texture = east_texture if facing == 1 else west_texture
	# Atlas bounds avoid the padding in the generated 136px character canvases.
	var bounds: Rect2i = body.texture.get_image().get_used_rect()
	body.region_enabled = true
	body.region_rect = Rect2(bounds)
	body.scale = Vector2.ONE * (76.0 / bounds.size.y)
	body.position = Vector2(0, -38)
	add_child(body)
	gun = Sprite2D.new()
	gun.texture = load("res://assets/weapons/%s.png" % weapon.id)
	gun.scale = Vector2.ONE * 0.78
	add_child(gun)
	pet = Sprite2D.new()
	pet.texture = load("res://assets/pets/%s.png" % ("fenix_dourada" if id == 0 else "raposa_glacial"))
	pet.scale = Vector2.ONE * 0.65
	add_child(pet)
	update_pose()

func update_pose() -> void:
	if body == null:
		return
	if is_boss:
		queue_redraw()
		return
	if is_instance_valid(idle_animation):
		idle_animation.flip_h = facing < 0
	body.texture = east_texture if facing == 1 else west_texture
	body.region_rect = Rect2(body.texture.get_image().get_used_rect())
	gun.position = Vector2(facing * 17, -30)
	gun.flip_h = facing < 0
	gun.rotation = (-deg_to_rad(angle) + 0.65) * facing
	pet.position = Vector2(-facing * 48, -12 + sin(pulse * 2.0) * 3.0)
	queue_redraw()

func muzzle() -> Vector2:
	if is_boss:
		return position + Vector2(-60, -95)
	return position + Vector2(facing * (22.0 + cos(deg_to_rad(angle)) * 22.0), -34.0 - sin(deg_to_rad(angle)) * 22.0)

func center() -> Vector2:
	return position + Vector2(0, -85 if is_boss else -32)

func step_fall(delta: float, terrain: DestructibleTerrain, gravity: float) -> void:
	pulse += delta
	if attack_time > 0:
		attack_time -= delta
		if attack_time <= 0:
			attack_animation.hide()
			idle_animation.show()
	if hp <= 0:
		return
	if terrain.solid(position + Vector2(0, 2)):
		velocity_y = 0
		settled = true
	else:
		settled = false
		velocity_y += gravity * delta
		var travel: float = velocity_y * delta
		var steps: int = maxi(1, ceili(travel / 2.0))
		for i in range(steps):
			if terrain.solid(position + Vector2(0, travel / steps + 1)):
				velocity_y = 0
				settled = true
				break
			position.y += travel / steps
	if position.y > 740:
		hp = 0
	update_pose()

func move_ground(amount: float, terrain: DestructibleTerrain) -> bool:
	if not settled or hp <= 0:
		return false
	var next_x: float = clampf(position.x + amount, 24, 1256)
	if is_equal_approx(next_x, position.x):
		return false
	# Climb small pixel steps but never teleport onto the far side of a crater.
	var top: float = terrain.surface_y(next_x, position.y - 10)
	if terrain.solid(Vector2(next_x, position.y - 12)):
		return false
	position.x = next_x
	if top <= position.y + 6:
		position.y = top - 1
	facing = 1 if amount > 0 else -1
	update_pose()
	return true

func take_damage(amount: int) -> void:
	hp = maxi(0, hp - amount)
	if amount > 0:
		body.modulate = Color("ff877a")
		create_tween().tween_property(body, "modulate", Color.WHITE, 0.4)

func _draw() -> void:
	if hp <= 0:
		return
	if active:
		draw_arc(Vector2(0, 2), 25, 0, PI, 20, Color("ffe0a1"), 3)
		draw_colored_polygon(PackedVector2Array([Vector2(-6, -96), Vector2(6, -96), Vector2(0, -87)]), Color("ffe0a1"))
	if shield:
		draw_arc(Vector2(0, -35), 44, 0, TAU, 40, Color(0.4, 0.85, 1.0, 0.75), 2)
