extends Node2D

var game: LocalMatch
var hud: GameHUD
var audio: GameAudio
var explosion: Texture2D = preload("res://assets/effects/explosao.png")
var ambience_time: float = 0
var capture_frames: int = 0
var temple_background: Texture2D = preload("res://assets/pve/templo_bg.png")
var hub_background: Texture2D = preload("res://assets/pve/hub_celeste.png")

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	audio = GameAudio.new()
	add_child(audio)
	game = LocalMatch.new()
	add_child(game)
	hud = GameHUD.new()
	hud.game = game
	hud.audio = audio
	var layer: CanvasLayer = CanvasLayer.new()
	add_child(layer)
	layer.add_child(hud)
	game.blast.connect(show_blast)
	game.damage_text.connect(show_damage)
	game.shot_fired.connect(func() -> void: audio.tone(190, 0.22))
	game.finished.connect(func(_winner: int) -> void: audio.tone(660, 0.75))
	if "--capture" in OS.get_cmdline_user_args():
		hud.start_match()
		capture_frames = 12
	elif "--capture-profile" in OS.get_cmdline_user_args():
		hud.show_profile()
		capture_frames = 12
	elif "--capture-hub" in OS.get_cmdline_user_args():
		capture_frames = 12

func _process(delta: float) -> void:
	for animation in get_tree().get_nodes_in_group("pixel_animations"):
		animation.frozen = game.paused
	if not game.paused:
		ambience_time += delta
	queue_redraw()
	if capture_frames > 0:
		capture_frames -= 1
		if capture_frames == 0:
			await RenderingServer.frame_post_draw
			var filename: String = "character_preview.png" if "--capture-profile" in OS.get_cmdline_user_args() else "combat_preview.png"
			if "--capture-hub" in OS.get_cmdline_user_args():
				filename = "pve_hub.png"
			get_viewport().get_texture().get_image().save_png("res://docs/" + filename)
			get_tree().quit()

func _draw() -> void:
	var scene_background: Texture2D = temple_background if is_instance_valid(game) and game.visible and game.pve else hub_background
	draw_texture_rect(scene_background, Rect2(0, 0, 1280, 720), false)
	draw_rect(Rect2(0, 0, 1280, 720), Color(0.11, 0.17, 0.3, 0.15))
	for i in range(18):
		var p: Vector2 = Vector2(fmod(i * 83.0 + ambience_time * 7, 1280), 145 + fmod(i * 37.0, 370))
		draw_rect(Rect2(p, Vector2(2, 2)), Color(1, 0.9, 0.7, 0.45))

func show_blast(point: Vector2, radius: float) -> void:
	audio.tone(80, 0.45, true)
	var sprite: Sprite2D = Sprite2D.new()
	sprite.texture = explosion
	sprite.position = point
	sprite.scale = Vector2.ONE * radius / 45.0
	add_child(sprite)
	var tween: Tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(sprite, "scale", sprite.scale * 1.65, 0.4)
	tween.tween_property(sprite, "modulate:a", 0.0, 0.45)
	tween.chain().tween_callback(sprite.queue_free)

func show_damage(point: Vector2, text: String, color: Color) -> void:
	var label: Label = Label.new()
	label.text = text
	label.position = point + Vector2(-18, -36)
	label.add_theme_font_size_override("font_size", 30)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color("182342"))
	label.add_theme_constant_override("shadow_offset_x", 2)
	label.add_theme_constant_override("shadow_offset_y", 2)
	add_child(label)
	var tween: Tween = create_tween().set_parallel(true)
	tween.tween_property(label, "position:y", label.position.y - 58, 1.0)
	tween.tween_property(label, "modulate:a", 0.0, 1.0)
	tween.chain().tween_callback(label.queue_free)
